close all;
clear;
clc;

% Damping Coefficients
speed = [-0.6 -0.3 -0.1 0 0.1 0.3 0.6];
front_forces = [-353  -235 -157 0 167 481 706];
rear_forces = [-304 -196 -79 0 373 647 1010];

fitted_line_front = polyfit(speed , front_forces , 1);
fitted_line_rear = polyfit(speed , rear_forces , 1);

y1_fit = polyval(fitted_line_front, speed);
y2_fit = polyval(fitted_line_rear, speed);

slope_front = fitted_line_front(1);
slope_rear = fitted_line_rear(1);

C1 = slope_front;
C2 = slope_rear;

%Vehicle Properties
m1 = 35;
m2 = 52;
m3 = 878;

K1 = 17650;
K2 = 22600;
Kt = 153000;

L = 2.415;
b1 = 1.007;
b2 = L - b1;

Iy = 1520;

%State Space Representation

A = [0 1 0 0 0 0 0 0;
    (-K1-Kt)/m1 -C1/m1 0 0 K1/m1 C1/m1 b1*K1/m1 b1*C1/m1;
    0 0 0 1 0 0 0 0;
    0 0 (-K2-Kt)/m2 -C2/m2 K2/m2 C2/m2 -b2*K2/m2 -b2*C2/m2;
    0 0 0 0 0 1 0 0;
    K1/m3 C1/m3 K2/m3 C2/m3 (-K1-K2)/m3 (-C1-C2)/m3 (b2*K2-b1*K1)/m3 (b2*C2-b1*C1)/m3;
    0 0 0 0 0 0 0 1;
    (b1*K1)/Iy (b1*C1)/Iy (-b2*K2)/Iy (-b2*C2)/Iy (b2*K2-b1*K1)/Iy (b2*C2-b1*C1)/Iy (-K1*b1^2-K2*b2^2)/Iy (-C1*b1^2-C2*b2^2)/Iy];

B = [0 0;
    Kt/m1 0;
    0 0;
    0 Kt/m2;
    0 0;
    0 0;
    0 0;
    0 0;];

% Solve the eigenvalue problem
[eigenvectors, eigenvalues] = eig(A);

% Natural frequencies
natural_frequencies = unique(abs(diag(eigenvalues))/(2*pi));

% Damping frequencies
damping_frequencies = unique(abs(imag(diag(eigenvalues)))/(2*pi));

format shortE

% Display results
disp('Natural Frequencies (Hz):');
disp(natural_frequencies);
disp('Damping Frequencies (Hz):');
disp(damping_frequencies);

mode_shapes = eigenvectors;
% Display the mode shapes
disp('Mode Shapes:');
disp(mode_shapes);