close all;
clear;
clc;

% Damping Coefficients
speed = [-0.6 -0.3 -0.1 0 0.1 0.3 0.6];
front_forces = [-353  -235 -157 0 167 481 706];
rear_forces = [-304 -196 -79 0 373 647 1010];

fitted_line_front = polyfit(speed, front_forces, 1);
fitted_line_rear = polyfit(speed, rear_forces, 1);

C1 = fitted_line_front(1); % Slope of front forces
C2 = fitted_line_rear(1); % Slope of rear forces

% Vehicle Properties
m1 = 35;
m2 = 52;
m3 = 1178;

K1 = 17650;
K2 = 22600;
Kt = 153000;

L = 2.415;
b1 = 1.167;
b2 = L - b1;

Iy = 2070;

% State Space Representation
A = [0 1 0 0 0 0 0 0;
    (-K1-Kt)/m1 -C1/m1 0 0 K1/m1 C1/m1 b1*K1/m1 b1*C1/m1;
    0 0 0 1 0 0 0 0;
    0 0 (-K2-Kt)/m2 -C2/m2 K2/m2 C2/m2 -b2*K2/m2 -b2*C2/m2;
    0 0 0 0 0 1 0 0;
    K1/m3 C1/m3 K2/m3 C2/m3 (-K1-K2)/m3 (-C1-C2)/m3 (b2*K2-b1*K1)/m3 (b2*C2-b1*C1)/m3;
    0 0 0 0 0 0 0 1;
    (b1*K1)/Iy (b1*C1)/Iy (-b2*K2)/Iy (-b2*C2)/Iy (b2*K2-b1*K1)/Iy (b2*C2-b1*C1)/Iy (-K1*b1^2-K2*b2^2)/Iy (-C1*b1^2-C2*b2^2)/Iy];

B = [0 0;
    Kt/m1 0;
    0 0;
    0 Kt/m2;
    0 0;
    0 0;
    0 0;
    0 0;];

C = [0 0 0 0 1 0 0 0];

D = [0 0];

% Find the transfer functions
[num, den] = ss2tf(A, B, C, D, 1);
transfer_function_1 = tf(num, den);
[num2, den2] = ss2tf(A, B, C, D, 2);
transfer_function_2 = tf(num2, den2);

% Load road profile
road_data = readtable('TypeD.xls');
x = road_data{:, 1};
displacement = road_data{:, 2};

% Convert velocity from km/h to m/s
velocity = 40 / 3.6;

% Estimate the sampling frequency
Fs = 1 / mean(diff(x));

% Calculate the time delay based on the wheelbase and velocity
time_delay = L / velocity;

% Shift the rear profile by the time delay
displacement_rear = interp1(x, displacement, x - time_delay, 'linear', 'extrap');

% Calculate PSD using the periodogram for both profiles
[spatial_psd_front, f] = periodogram(displacement, [], 200, Fs);
[spatial_psd_rear, ~] = periodogram(displacement_rear, [], 200, Fs);

time_frequency_psd_front = spatial_psd_front / velocity;
time_frequency_psd_rear = spatial_psd_rear / velocity;

% Plot the PSD
figure;
subplot(2,1,1);
plot(f, 10 * log10(time_frequency_psd_front),'linewidth',2); % Convert to dB
title('Power Spectral Density of Front Wheel Type D Road Profile in Time Frequency');
xlabel('Frequency (Hz)');
ylabel('Power/Frequency (dB/Hz)');
grid on;

subplot(2,1,2);
plot(f, 10 * log10(time_frequency_psd_rear),'linewidth',2); % Convert to dB
title('Power Spectral Density of Rear Wheel Type D Road Profile in Time Frequency');
xlabel('Frequency (Hz)');
ylabel('Power/Frequency (dB/Hz)');
grid on;

% Evaluate the transfer functions and calculate the response
rms_values_front = zeros(1, length(f)-1);
rms_values_rear = zeros(1, length(f)-1);

for index = 2:length(f)
    H_jw_1 = evalfr(transfer_function_1, 1i * f(index));
    response_front = time_frequency_psd_front(index) * abs(H_jw_1)^2;
    rms_front = sqrt(response_front * (f(index) - f(index - 1)));
    rms_values_front(index-1) = rms_front;
    
    H_jw_2 = evalfr(transfer_function_2, 1i * f(index));
    response_rear = time_frequency_psd_rear(index) * abs(H_jw_2)^2;
    rms_rear = sqrt(response_rear * (f(index) - f(index - 1)));
    rms_values_rear(index-1) = rms_rear;
end

% Combine the responses (assuming linear superposition)
combined_rms_values = rms_values_front + rms_values_rear;

% Plot RMS Acceleration
figure;
semilogx(f(2:end), rms_values_front, 'r', 'DisplayName', 'Front Wheel Response','linewidth',2);
hold on;
semilogx(f(2:end), rms_values_rear, 'b', 'DisplayName', 'Rear Wheel Response','linewidth',2);
semilogx(f(2:end), combined_rms_values, 'k', 'DisplayName', 'Total Response','linewidth',2);
title('RMS Acceleration per Frequency for Front and Rear Type D Road Profiles');
xlabel('Frequency (Hz)');
ylabel('RMS Acceleration (m/s^2)');
legend show;
hold off;
grid on;

%ISO 2631-1
frequency = [1.0, 1.25, 1.6, 2.0, 2.5, 3.15, 4.0, 5.0, 6.3, 8.0, 10.0, 12.5, 16.0, 20.0, 25.0, 31.5, 40.0, 50.0, 63.0, 80.0];

% Define the acceleration values for each exposure time
acc_8h = [0.63, 0.56, 0.50, 0.45, 0.40, 0.355, 0.315, 0.315, 0.315, 0.315, 0.40, 0.50, 0.63, 0.80, 1, 1.25, 1.60, 2.0, 2.5, 3.15];
acc_24h = [0.280, 0.250, 0.224, 0.200, 0.180, 0.160, 0.140, 0.140, 0.140, 0.140, 0.180, 0.224, 0.280, 0.355, 0.450, 0.560, 0.710, 0.900, 1.120, 1.400];
acc_16h = [0.425, 0.375, 0.335, 0.300, 0.265, 0.235, 0.212, 0.212, 0.212, 0.212, 0.265, 0.335, 0.425, 0.530, 0.670, 0.850, 1.060, 1.320,1.700,2.120];
figure;
hold on;
% Plot the acceleration per frequency for different time scenarios
plot(frequency, acc_8h, 'DisplayName', '8 Hours(ISO)','linewidth',2);
plot(frequency, acc_16h, 'DisplayName', '16 Hours(ISO)','linewidth',2);
plot(frequency, acc_24h, 'DisplayName', '24 Hours(ISO)','linewidth',2);

plot(f(2:end), combined_rms_values, 'k', 'DisplayName', 'Vehicle Response','linewidth',2);

title('Ride Comfort Criteria for Type D Road Profile');
xlabel('Frequency (Hz)');
ylabel('RMS Acceleration (m/s^2)');

set(gca, 'XScale', 'log');% Set the x-axis to a logarithmic scale
set(gca, 'YScale', 'log');

hold off;
legend show;
grid on;