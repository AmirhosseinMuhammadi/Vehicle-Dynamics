close all;
clear;
clc;
speed = [-0.6 -0.3 -0.1 0 0.1 0.3 0.6];
front_forces = [-353  -235 -157 0 167 481 706];
rear_forces = [-304 -196 -79 0 373 647 1010];

fitted_line_front = polyfit(speed , front_forces , 1);
fitted_line_rear = polyfit(speed , rear_forces , 1);

y1_fit = polyval(fitted_line_front, speed);
y2_fit = polyval(fitted_line_rear, speed);

slope_front = fitted_line_front(1);
slope_rear = fitted_line_rear(1);

disp(slope_front);
disp(slope_rear);

hold on;
scatter(speed , front_forces , 'b' , 'DisplayName' , 'Experimental Front Forces');
scatter(speed , rear_forces , 'r' , 'DisplayName' , 'Experimental Rear Forces');
plot(speed , y1_fit , 'b' , 'DisplayName' , 'Fitted Line for Front Forces');
plot(speed , y2_fit , 'r' , 'DisplayName' , 'Fitted Line for Rear Forces');

title('Damping Force - Vertical Velocity');
xlabel('Vertical Velocity (m/s)');
ylabel('Damping Force(N)');
legend('show');
set(legend, 'FontSize', 14);
grid on;
hold off;