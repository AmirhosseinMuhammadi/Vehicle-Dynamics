close all;
clear;
clc;

% Damping Coefficients
speed = [-0.6 -0.3 -0.1 0 0.1 0.3 0.6];
front_forces = [-353  -235 -157 0 167 481 706];
rear_forces = [-304 -196 -79 0 373 647 1010];

fitted_line_front = polyfit(speed, front_forces, 1);
fitted_line_rear = polyfit(speed, rear_forces, 1);

C1 = fitted_line_front(1); % Slope of front forces
C2 = fitted_line_rear(1); % Slope of rear forces

% Vehicle Properties
m1 = 35;
m2 = 52;
m3 = 878;

K1 = 17650;
K2 = 22600;
Kt = 153000;

L = 2.415; % Wheelbase in meters
b1 = 1.007;
b2 = L - b1;

Iy = 1520;

% State Space Representation
A = [0 1 0 0 0 0 0 0;
    (-K1-Kt)/m1 -C1/m1 0 0 K1/m1 C1/m1 b1*K1/m1 b1*C1/m1;
    0 0 0 1 0 0 0 0;
    0 0 (-K2-Kt)/m2 -C2/m2 K2/m2 C2/m2 -b2*K2/m2 -b2*C2/m2;
    0 0 0 0 0 1 0 0;
    K1/m3 C1/m3 K2/m3 C2/m3 (-K1-K2)/m3 (-C1-C2)/m3 (b2*K2-b1*K1)/m3 (b2*C2-b1*C1)/m3;
    0 0 0 0 0 0 0 1;
    (b1*K1)/Iy (b1*C1)/Iy (-b2*K2)/Iy (-b2*C2)/Iy (b2*K2-b1*K1)/Iy (b2*C2-b1*C1)/Iy (-K1*b1^2-K2*b2^2)/Iy (-C1*b1^2-C2*b2^2)/Iy];

% Road disturbance as additional inputs
B = [0 0;
    Kt/m1 0;
    0 0;
    0 Kt/m2;
    0 0;
    0 0;
    0 0;
    0 0];

C = [0 0 0 0 1 0 0 0];

D = [0 0];

velocities = [80 , 40]/3.6;

figure;
hold on;
for velocity=velocities
    % Time vector
    t = 0:0.01:5;

    % Spatial profile of speed breaker
    width_sb = 0.5; % Width of speed breaker (meters)
    height_sb = 0.1; % Height of speed breaker (meters)

    % Convert spatial input to time-domain input based on vehicle speed
    time_sb = width_sb / velocity; % Time to travel over speed breaker
    start_time = 0; % Start time when vehicle encounters speed breaker

    % Road profile under front and rear wheels (Speed breaker)
    road_profile_front = zeros(size(t));
    road_profile_rear = zeros(size(t));
    for i = 1:length(t)
        if t(i) >= start_time && t(i) <= start_time + time_sb
            road_profile_front(i) = height_sb * sin(pi * (t(i) - start_time) / time_sb);
        end
        if t(i) >= start_time + b2 / velocity && t(i) <= start_time + b2 / velocity + time_sb
            road_profile_rear(i) = height_sb * sin(pi * (t(i) - (start_time + b2 / velocity)) / time_sb);
        end
    end

    % Simulate the system response
    sys = ss(A, B, C, D);
    u = [road_profile_front; road_profile_rear];
    [y, t, x] = lsim(sys, u', t);

    % Plot the response
    plot(t, y, 'linewidth',2);
end
title('Vehicle Response to Speed Breaker');
xlabel('Time (s)');
ylabel('Sprung Mass Displacement (m)');
grid on;
legend('80 km/h', '40 km/h');
hold off;
