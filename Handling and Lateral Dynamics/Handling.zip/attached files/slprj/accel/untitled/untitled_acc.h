#include "__cf_untitled.h"
#ifndef RTW_HEADER_untitled_acc_h_
#define RTW_HEADER_untitled_acc_h_
#include <stddef.h>
#ifndef untitled_acc_COMMON_INCLUDES_
#define untitled_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "untitled_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T a4ugqgg3dn ; real_T agg1ei0mzh ; real_T ew3a5ynmy0 ;
real_T npujcj2gii ; real_T fvjzs2yqop ; real_T p2yjukcdxz ; real_T khls00oqdl
; real_T dfktfytkyh ; real_T i4hmwd4dyn ; real_T l5glmclzk5 ; real_T
hsyfo4vrqo ; real_T oezin1ztye ; real_T dboljg0zjh ; real_T jxxxrzovzn ;
real_T cjalgfzrup ; real_T bmf1apxqai ; real_T nft2xemhbk ; } fsg2leehhc ;
typedef struct { real_T oowkhzv5gr ; real_T iu4aalx5k4 ; real_T jvjjxb51tx ;
real_T cdui3qi1l5 ; real_T aat2tx32vq ; struct { void * LoggedData ; }
lttxbcd5kg ; struct { void * LoggedData ; } ex4blwz34e ; struct { void *
LoggedData ; } mvgvr3fk0h ; struct { void * LoggedData ; } erjujdghwj ; int_T
ptct03fqp3 ; int_T j5vpnpjceh ; } kywlqvr0yp ; typedef struct { real_T
p2sryzupsg ; real_T avk0fxk0yr ; real_T auw2cxxhz4 ; real_T iweqnczir2 ; }
duq1u2s0wi ; typedef struct { real_T p2sryzupsg ; real_T avk0fxk0yr ; real_T
auw2cxxhz4 ; real_T iweqnczir2 ; } d1e4i05lcy ; typedef struct { boolean_T
p2sryzupsg ; boolean_T avk0fxk0yr ; boolean_T auw2cxxhz4 ; boolean_T
iweqnczir2 ; } bav3foezld ; typedef struct { real_T p2sryzupsg ; real_T
avk0fxk0yr ; real_T auw2cxxhz4 ; real_T iweqnczir2 ; } luc33gt052 ; typedef
struct { real_T auzzs3ujgy ; real_T lqh2upwx0a ; real_T hd0523vtap ; }
avyyf1we1b ; typedef struct { ZCSigState ko30vpkkhv ; ZCSigState f0au1imz5m ;
ZCSigState evlpx1wabp ; } dhdamvhoj3 ; struct g0szqdi43g_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; } ; extern g0szqdi43g
lxkrdcync0 ;
#endif
