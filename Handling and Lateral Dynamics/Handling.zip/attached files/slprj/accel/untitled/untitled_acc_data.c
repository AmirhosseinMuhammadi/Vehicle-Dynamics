#include "__cf_untitled.h"
#include "untitled_acc.h"
#include "untitled_acc_private.h"
g0szqdi43g lxkrdcync0 = { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 0.0 , 0.0 , 4.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ;
