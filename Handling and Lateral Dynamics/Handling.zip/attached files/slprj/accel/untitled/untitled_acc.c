#include "__cf_untitled.h"
#include <math.h>
#include "untitled_acc.h"
#include "untitled_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T i3eepunmpp ;
real_T currentTime ; fsg2leehhc * _rtB ; g0szqdi43g * _rtP ; kywlqvr0yp *
_rtDW ; _rtDW = ( ( kywlqvr0yp * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
g0szqdi43g * ) ssGetDefaultParam ( S ) ) ; _rtB = ( ( fsg2leehhc * )
_ssGetBlockIO ( S ) ) ; _rtB -> a4ugqgg3dn = ( ( duq1u2s0wi * )
ssGetContStates ( S ) ) -> p2sryzupsg ; ssCallAccelRunBlock ( S , 3 , 1 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> agg1ei0mzh = ( ( duq1u2s0wi * )
ssGetContStates ( S ) ) -> avk0fxk0yr ; ssCallAccelRunBlock ( S , 3 , 3 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> ew3a5ynmy0 = ( ( duq1u2s0wi * )
ssGetContStates ( S ) ) -> auw2cxxhz4 ; ssCallAccelRunBlock ( S , 3 , 5 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime =
ssGetTaskTime ( S , 1 ) ; _rtDW -> ptct03fqp3 = ( currentTime >= _rtP -> P_3
) ; if ( _rtDW -> ptct03fqp3 == 1 ) { _rtB -> npujcj2gii = _rtP -> P_5 ; }
else { _rtB -> npujcj2gii = _rtP -> P_4 ; } } i3eepunmpp = ssGetT ( S ) ; if
( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> fvjzs2yqop = _rtP -> P_6 ; _rtB ->
p2yjukcdxz = _rtP -> P_7 ; } _rtB -> khls00oqdl = ( i3eepunmpp - _rtB ->
fvjzs2yqop ) * _rtB -> npujcj2gii + _rtB -> p2yjukcdxz ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> j5vpnpjceh = _rtB -> khls00oqdl >= _rtP
-> P_8 ? 1 : _rtB -> khls00oqdl > _rtP -> P_9 ? 0 : - 1 ; } _rtB ->
dfktfytkyh = _rtDW -> j5vpnpjceh == 1 ? _rtP -> P_8 : _rtDW -> j5vpnpjceh ==
- 1 ? _rtP -> P_9 : _rtB -> khls00oqdl ; ssCallAccelRunBlock ( S , 3 , 14 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> i4hmwd4dyn = ( ( duq1u2s0wi * )
ssGetContStates ( S ) ) -> iweqnczir2 ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
_rtB -> l5glmclzk5 = _rtDW -> oowkhzv5gr ; _rtB -> hsyfo4vrqo = _rtDW ->
iu4aalx5k4 ; _rtB -> oezin1ztye = _rtDW -> jvjjxb51tx ; } ssCallAccelRunBlock
( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 1 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB ->
dboljg0zjh = _rtDW -> cdui3qi1l5 ; _rtB -> jxxxrzovzn = _rtDW -> aat2tx32vq ;
ssCallAccelRunBlock ( S , 2 , 0 , SS_CALL_MDL_OUTPUTS ) ; } UNUSED_PARAMETER
( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { fsg2leehhc * _rtB ;
g0szqdi43g * _rtP ; kywlqvr0yp * _rtDW ; _rtDW = ( ( kywlqvr0yp * )
ssGetRootDWork ( S ) ) ; _rtP = ( ( g0szqdi43g * ) ssGetDefaultParam ( S ) )
; _rtB = ( ( fsg2leehhc * ) _ssGetBlockIO ( S ) ) ; if ( ssIsSampleHit ( S ,
1 , 0 ) ) { _rtDW -> oowkhzv5gr = _rtB -> a4ugqgg3dn ; _rtDW -> iu4aalx5k4 =
_rtB -> agg1ei0mzh ; _rtDW -> jvjjxb51tx = _rtB -> cjalgfzrup ; _rtDW ->
cdui3qi1l5 = _rtB -> nft2xemhbk ; _rtDW -> aat2tx32vq = _rtB -> ew3a5ynmy0 ;
} UNUSED_PARAMETER ( tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { fsg2leehhc * _rtB ; g0szqdi43g
* _rtP ; _rtP = ( ( g0szqdi43g * ) ssGetDefaultParam ( S ) ) ; _rtB = ( (
fsg2leehhc * ) _ssGetBlockIO ( S ) ) ; { ( ( d1e4i05lcy * ) ssGetdX ( S ) )
-> p2sryzupsg = _rtB -> nft2xemhbk ; } { ( ( d1e4i05lcy * ) ssGetdX ( S ) )
-> avk0fxk0yr = _rtB -> bmf1apxqai ; } { ( ( d1e4i05lcy * ) ssGetdX ( S ) )
-> auw2cxxhz4 = _rtB -> i4hmwd4dyn ; } { ( ( d1e4i05lcy * ) ssGetdX ( S ) )
-> iweqnczir2 = _rtB -> cjalgfzrup ; } }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { fsg2leehhc * _rtB ;
g0szqdi43g * _rtP ; avyyf1we1b * _rtZCSV ; _rtZCSV = ( ( avyyf1we1b * )
ssGetSolverZcSignalVector ( S ) ) ; _rtP = ( ( g0szqdi43g * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( fsg2leehhc * ) _ssGetBlockIO ( S ) ) ;
_rtZCSV -> auzzs3ujgy = ssGetT ( S ) - _rtP -> P_3 ; _rtZCSV -> lqh2upwx0a =
_rtB -> khls00oqdl - _rtP -> P_8 ; _rtZCSV -> hd0523vtap = _rtB -> khls00oqdl
- _rtP -> P_9 ; } static void mdlInitializeSizes ( SimStruct * S ) {
ssSetChecksumVal ( S , 0 , 950215942U ) ; ssSetChecksumVal ( S , 1 ,
3632204102U ) ; ssSetChecksumVal ( S , 2 , 561220145U ) ; ssSetChecksumVal (
S , 3 , 3403120126U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.5" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
kywlqvr0yp ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( fsg2leehhc ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
g0szqdi43g ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & lxkrdcync0 ) ; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static
void mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct * childS ;
SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ; callSysFcns
= ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 1 ) ; callSysFcns =
ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 2 ) ; callSysFcns =
ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; } } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
