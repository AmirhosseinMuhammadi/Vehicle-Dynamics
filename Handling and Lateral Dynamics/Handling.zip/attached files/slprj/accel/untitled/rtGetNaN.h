#include "__cf_untitled.h"
#ifndef RTW_HEADER_rtGetNaN_h_
#define RTW_HEADER_rtGetNaN_h_
#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"
extern real_T rtGetNaN ( void ) ; extern real32_T rtGetNaNF ( void ) ;
#endif
