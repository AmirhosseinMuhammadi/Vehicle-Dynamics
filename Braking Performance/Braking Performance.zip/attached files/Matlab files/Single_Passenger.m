close all;
clear;
clc;

M = 1077;
L = 2.415;
b = 1.007;
c = L - b;
h = 0.498;

g = 9.81;

W = M*g;
W_fs = (c*W) / L;
W_rs = (b*W) / L;

mu1 = 0.3;
mu2 = 0.8;

% for mu = 0.3
slope1 = (mu1*h/L) / (1 - mu1*h/L);
intercept1 = (mu1*W_fs) /(1 - mu1*h/L);

slope2 = (-mu1*h/L) / (1 + mu1*h/L);
intercept2 = (mu1*W_rs) /(1 + mu1*h/L);

figure;
grid on;
hold on;
x = linspace(0 , 4000 , 1000);
y1 = slope1*x + intercept1;
plot(x , y1 , 'linewidth' , 2);

y2 = slope2*x + intercept2;
plot(y2 , x , 'linewidth' , 2);

y3 = -x + (0.1 + 0.7*(mu1 - 0.2))*W;
plot(x , y3 , 'linewidth' , 2);

x_intersection = (intercept1 + intercept2/slope2) / (1/slope2 - slope1);
y_intersection = slope1*x_intersection + intercept1;
slope4 = y_intersection/x_intersection;
y4 = slope4*x;
plot(x , y4 , 'linewidth' , 2);
disp('The Brake Proportioning(mu=0.3) =');
disp(slope4);

ylim([0,4000]);
title('Maximum Braking Forces for Single Passenger (Friction coefficient = 0.3)');
xlabel('Rear Brake Force(N)');
ylabel('Front Brake Force(N)');
legend('Front Lockup' , 'Rear Lockup' , 'Constant Deceleration' , 'Proportioning Line');
hold off;

% stop time
v = 100/3.6;
t = (M*v) / (x_intersection + y_intersection);
disp('time to stop (mu=0.3) =');
disp(t);

% for mu = 0.8
slope1 = (mu2*h/L) / (1 - mu2*h/L);
intercept1 = (mu2*W_fs) /(1 - mu2*h/L);

slope2 = (-mu2*h/L) / (1 + mu2*h/L);
intercept2 = (mu2*W_rs) /(1 + mu2*h/L);

figure;
grid on;
hold on;
x = linspace(0 , 7000 , 1000);
y1 = slope1*x + intercept1;
plot(x , y1 , 'linewidth' , 2);

y2 = slope2*x + intercept2;
plot(y2 , x , 'linewidth' , 2);

y3 = -x + (0.1 + 0.7*(mu2 - 0.2))*W;
plot(x , y3 , 'linewidth' , 2);

x_intersection = (intercept1 + intercept2/slope2) / (1/slope2 - slope1);
y_intersection = slope1*x_intersection + intercept1;
slope4 = y_intersection/x_intersection;
y4 = slope4*x;
plot(x , y4 , 'linewidth' , 2);
disp('The Brake Proportioning(mu=0.8) =');
disp(slope4);

ylim([0,7000]);
title('Maximum Braking Forces for Single Passenger (Friction coefficient = 0.8)');
xlabel('Rear Brake Force(N)');
ylabel('Front Brake Force(N)');
legend('Front Lockup' , 'Rear Lockup' , 'Constant Deceleration' , 'Proportioning Line');
hold off;

% stop time
v = 100/3.6;
t = (M*v) / (x_intersection + y_intersection);
disp('time to stop (mu=0.8) =');
disp(t);
